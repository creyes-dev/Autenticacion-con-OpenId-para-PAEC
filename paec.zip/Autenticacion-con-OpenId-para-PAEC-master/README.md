# Autenticacion con OpenId para PAEC

Armado de una aplicación en .Net 4.x para autenticarse con PAEC por medio de OpenID siguiendo el protocolo OAuth2.0, obtención de datos de usuario y cierre de sesión en PAEC. <br/>

Herramientas utilizadas:
* IDE Visual Studio 2013 Version 12.0.40629 Update 5
* NuGet Package Manager 2.12.0.817

Paquetes instalados:<br/>
* Owin.Security.Keycloak-3 -Version 3.0.5
* Microsoft.Owin.Host.SystemWeb -Version 4.0.1
* Microsoft.Owin.Security.Cookies -Version 4.0.1
